CREATE TABLE `club_keys` (
 `code` text PRIMARY KEY NOT NULL,
 `batch_id` text NOT NULL,
 `label` text NOT NULL,
 `created_at` text NOT NULL,
 `expires_at` text,
 `cancelled` integer DEFAULT 0 NOT NULL,
 `used_by` text,
 `used_email` text,
 `used_at` text
);
--> statement-breakpoint
CREATE INDEX `club_keys_user` ON `club_keys` (`used_by`);
--> statement-breakpoint
CREATE TABLE `club_redemptions` (
 `id` text PRIMARY KEY NOT NULL,
 `user_id` text NOT NULL,
 `email` text NOT NULL,
 `reward_id` text NOT NULL,
 `name` text NOT NULL,
 `cost` integer NOT NULL,
 `created_at` text NOT NULL,
 `status` text DEFAULT 'pending' NOT NULL
);
--> statement-breakpoint
CREATE INDEX `club_redemptions_user` ON `club_redemptions` (`user_id`);
--> statement-breakpoint
CREATE TABLE `club_rewards` (
 `id` text PRIMARY KEY NOT NULL,
 `stock` integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE TABLE `club_settings` (
 `id` text PRIMARY KEY NOT NULL,
 `goal` integer DEFAULT 100 NOT NULL
);
