CREATE TABLE club_profile_photos (user_id TEXT PRIMARY KEY NOT NULL, photo TEXT NOT NULL, updated_at TEXT NOT NULL);
