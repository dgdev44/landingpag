Brand vectors used in reward cards:

- ChatGPT / OpenAI: Simple Icons v15, openai.svg (brand symbol).
- Claude: Simple Icons v15, claude.svg (brand symbol).
- PlayStation: Simple Icons v15, playstation.svg; gold color for Deluxe card.
- Manus: SVG brand mark from https://manus.im (official home page); fixed white logo color for dark card.

Retrieved 2026-11-11. Original geometry preserved; no generated images.

2026-11-11 banner updates:
- Disney+: full original logo from disneyplus.com, disney.images.edge.bamgrid.com.
- Rakuten Viki: original horizontal white brand SVG referenced by viki.com.
- Premiere: original vector header logo from premiere.globo.com production client bundle (app-client-bundle-8d36287e.js, original SVG module 1211).

2026-11-11 catalog expansion:
- Sky wordmark, Paramount+, Strava and Tidal symbols: Simple Icons v15; vector geometry preserved.
- Deezer, Amazon Music, NFL, Claro TV+ and Free Fire: retained original official website brand assets from the previously verified DG Shop catalog.
- Restored eight original product IDs/prices; points remain ceil(sourcePrice), and existing reward IDs/history remain unchanged.

2026-11-11 additional services:
- CapCut, Apple TV, Lumine, Perplexity, Darkflix, Magnific, NordVPN, KOCOWA+ and iQIYI: existing original website icons preserved, without generated replacements or recoloring.
- Amazon Kindle: original application icon from Amazon's App Store listing https://apps.apple.com/br/app/amazon-kindle/id302584613 (Apple CDN AppIcon-0-0-1x_U007emarketing-0-7-0-sRGB-0-0-85-220.png).
- Sky: original vector geometry; red presentation (#e00022), with image color filters disabled.

2026-11-11 full banner lockups (replacing favicon tiles):
- CapCut: original header SVG from https://www.capcut.com.
- Apple TV: Apple TV vector wordmark (Simple Icons), white variant on black.
- Lumine: https://lumine.tv/brand/lumine-white-640.webp.
- Perplexity: https://upload.wikimedia.org/wikipedia/commons/1/1d/Perplexity_AI_logo.svg (original brand geometry).
- Darkflix: original skull/wordmark image from the official annual landing page https://anual.darkflixplus.com.br/.
- Magnific: https://media.magnific.com/images/logos/magnific.svg.
- NordVPN: https://upload.wikimedia.org/wikipedia/commons/4/48/NordVPN_logo.svg (source credited to official brand assets).
- Kindle: https://upload.wikimedia.org/wikipedia/commons/2/20/Amazon_Kindle_logo.svg.
- KOCOWA: KOCOWA_BI_White.png from https://corp.kocowa.com/wp-content/uploads/2016/08/KOCOWA_BI_White.zip.
- iQIYI: original header SVG from https://www.iq.com.
- Claro TV+: official white/red lockup https://upload.wikimedia.org/wikipedia/commons/6/6b/Claro_TV%2B_logo_%28white%29.svg, credited to Claro's original assets.
