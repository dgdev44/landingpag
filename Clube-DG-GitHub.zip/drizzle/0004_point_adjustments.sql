CREATE TABLE club_point_adjustments (id TEXT PRIMARY KEY NOT NULL, user_id TEXT NOT NULL, operation TEXT NOT NULL CHECK(operation IN ('add','remove','reset')), delta INTEGER NOT NULL, points_before INTEGER NOT NULL, points_after INTEGER NOT NULL CHECK(points_after>=0), reason TEXT NOT NULL, admin_user_id TEXT NOT NULL, admin_email TEXT NOT NULL, created_at TEXT NOT NULL);
--> statement-breakpoint
CREATE INDEX club_point_adjustments_user ON club_point_adjustments(user_id,created_at);
