CREATE TABLE `club_profiles` (
 `user_id` text PRIMARY KEY NOT NULL,
 `full_name` text NOT NULL,
 `contact_email` text NOT NULL,
 `phone` text,
 `created_at` text NOT NULL,
 `updated_at` text NOT NULL
);
