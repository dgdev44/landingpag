import {REWARDS} from './catalog.mjs';
const result=(value,status=200)=>Response.json(value,{status,headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
const fail=(msg,status=400)=>result({error:msg},status);
const used='(SELECT (SELECT COUNT(*) FROM club_keys k WHERE k.used_by=u.id)+COALESCE((SELECT SUM(delta) FROM club_point_adjustments a WHERE a.user_id=u.id),0) FROM (SELECT ? id) u)';
const spent='(SELECT COALESCE(SUM(cost),0) FROM club_redemptions WHERE user_id = ?)';
const random=()=> 'DG-'+Array.from(crypto.getRandomValues(new Uint8Array(16)),x=>x.toString(16).padStart(2,'0')).join('').toUpperCase().match(/.{1,8}/g).join('-');
const publicDemoState=()=>({guest:true,admin:false,email:'',profile:null,demoPoints:0,demoMode:true,rewards:REWARDS,stock:Object.fromEntries(REWARDS.map(r=>[r.id,10])),activations:[],redemptions:[]});
const secureHex=bytes=>Array.from(bytes,b=>b.toString(16).padStart(2,'0')).join('');
const secureToken=()=>secureHex(crypto.getRandomValues(new Uint8Array(32)));
const secureDigest=async value=>secureHex(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(value))));
async function passwordHash(password,salt){const key=await crypto.subtle.importKey('raw',new TextEncoder().encode(password),'PBKDF2',false,['deriveBits']);return secureHex(new Uint8Array(await crypto.subtle.deriveBits({name:'PBKDF2',salt:new TextEncoder().encode(salt),iterations:100000,hash:'SHA-256'},key,256)))}
const secureEqual=(a,b)=>{if(a.length!==b.length)return false;let diff=0;for(let i=0;i<a.length;i++)diff|=a.charCodeAt(i)^b.charCodeAt(i);return diff===0};
async function securityGate(req,env,uid){
 const url=new URL(req.url),path=url.pathname,db=env.DB;if(!db)return fail('Armazenamento indisponível.',503);
 const q=(s,...v)=>db.prepare(s).bind(...v),now=Date.now();
 const account=(await q('SELECT * FROM club_passwords WHERE user_id=?',uid).all()).results[0];
 const token=(req.headers.get('cookie')||'').split(';').map(x=>x.trim()).find(x=>x.startsWith('__Host-dg_session='))?.slice(18)||'';
 const session=token&&/^[a-f0-9]{64}$/.test(token)?(await q('SELECT user_id FROM club_sessions WHERE token_hash=? AND user_id=? AND expires_at>?',await secureDigest(token),uid,now).all()).results[0]:null;
 if(path==='/api/security'&&req.method==='GET')return result({stage:!account?'create':session?'ready':'unlock'});
 if(path.startsWith('/api/security/')&&req.method==='POST'){
  if(req.headers.get('origin')!==url.origin)return fail('Origem não autorizada.',403);
  if(!req.headers.get('content-type')?.includes('application/json'))return fail('Formato inválido.',415);
  let b;try{const raw=await req.text();if(raw.length>4096)return fail('Solicitação muito grande.',413);b=JSON.parse(raw)}catch{return fail('Solicitação inválida.')}
  const expiredCookie='__Host-dg_session=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0';
  const reply=(value,cookie)=>Response.json(value,{headers:{'Cache-Control':'no-store','Set-Cookie':cookie,'X-Content-Type-Options':'nosniff'}});
  if(path==='/api/security/logout'){if(token)await q('DELETE FROM club_sessions WHERE token_hash=?',await secureDigest(token)).run();return reply({message:'Conta bloqueada.'},expiredCookie)}
  if(account?.locked_until>now)return fail('Muitas tentativas. Aguarde 15 minutos e tente novamente.',429);
  const password=String(b.password||'');
  if(path==='/api/security/create'){
   if(account)return fail('Esta conta já possui senha. Entre com sua senha.',409);
   if(password.length<10||password.length>128||!/[a-zA-Z]/.test(password)||!/[0-9]/.test(password))return fail('Use de 10 a 128 caracteres, com letras e números.');
   const salt=secureToken();try{await q('INSERT INTO club_passwords(user_id,salt,password_hash,failed_attempts,locked_until,updated_at) VALUES(?,?,?,0,0,?)',uid,salt,await passwordHash(password,salt),now).run()}catch{return fail('Esta conta já possui senha. Atualize a página.',409)}
  }else if(path==='/api/security/unlock'){
   if(!account||password.length>128)return fail('Senha incorreta.',401);
   if(!secureEqual(await passwordHash(password,account.salt),account.password_hash)){
    await q('UPDATE club_passwords SET failed_attempts=CASE WHEN locked_until>0 AND locked_until<=? THEN 1 ELSE failed_attempts+1 END, locked_until=CASE WHEN locked_until>0 AND locked_until<=? THEN 0 WHEN failed_attempts>=4 THEN ? ELSE 0 END WHERE user_id=?',now,now,now+900000,uid).run();return fail('Senha incorreta.',401);
   }
   await q('UPDATE club_passwords SET failed_attempts=0,locked_until=0 WHERE user_id=?',uid).run();
  }else return fail('Operação não encontrada.',404);
  const newToken=secureToken();await db.batch([q('DELETE FROM club_sessions WHERE user_id=? OR expires_at<=?',uid,now),q('INSERT INTO club_sessions(token_hash,user_id,expires_at) VALUES(?,?,?)',await secureDigest(newToken),uid,now+28800000)]);
  return reply({message:'Acesso liberado.'},'__Host-dg_session='+newToken+'; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=28800');
 }
 if(!session)return fail('Desbloqueie sua conta com a senha do clube.',423);
 return null;
}

export async function api(req,env){
 const url=new URL(req.url),path=url.pathname;const uid=req.headers.get('oai-authenticated-user-id'),email=req.headers.get('oai-authenticated-user-email')||'';
 if(path==='/api/state'&&req.method==='GET'&&(!uid||url.searchParams.get('demo')==='1'))return result(publicDemoState());
 if(!uid)return fail('Entre na sua conta para continuar.',401);
 try{const gate=await securityGate(req,env,uid);if(gate)return gate}catch{return fail('Não foi possível verificar o acesso. Tente novamente.',503)}
 const adminEmails=String(env.ADMIN_EMAILS||env.ADMIN_EMAIL||'').split(',').map(s=>s.trim().toLowerCase()).filter(Boolean);const admin=adminEmails.includes(email.trim().toLowerCase());
 if(env.PUBLIC_DEMO==='true'&&!admin){if(path==='/api/state'&&req.method==='GET')return result(publicDemoState());return fail('O site está em demonstração. Use as funções de teste no navegador.',403);}
 const demoPoints=admin?Math.max(0,Math.min(10000,Math.floor(Number(env.DEMO_POINTS)||0))):0;
 if(path.startsWith('/api/admin/')&&!admin)return fail('Acesso restrito à administração.',403);
 const db=env.DB;if(!db)return fail('Armazenamento indisponível. Tente novamente.',503);
 const q=(s,...v)=>db.prepare(s).bind(...v);
 const bodyLimit=path==='/api/profile/photo'?150000:32000;let body={};if(req.method!=='GET'){
  if(req.headers.get('origin')!==url.origin)return fail('Origem não autorizada.',403);
  if(!req.headers.get('content-type')?.includes('application/json'))return fail('Formato inválido.',415);
  if(Number(req.headers.get('content-length'))>bodyLimit)return fail('Solicitação muito grande.',413);
  try{const raw=await req.text();if(raw.length>bodyLimit)return fail('Solicitação muito grande.',413);body=JSON.parse(raw);}catch{return fail('Solicitação inválida.');}
 }
 try{
 if(path==='/api/state'&&req.method==='GET'){
  const data=await db.batch([q('SELECT id,stock FROM club_rewards'),q('SELECT code,used_at FROM club_keys WHERE used_by = ? ORDER BY used_at DESC',uid),q('SELECT id,name,reward_id,cost,created_at,status FROM club_redemptions WHERE user_id = ? ORDER BY created_at DESC',uid),q('SELECT p.full_name,p.contact_email,p.phone,f.photo FROM club_profiles p LEFT JOIN club_profile_photos f ON f.user_id=p.user_id WHERE p.user_id = ?',uid),q('SELECT COALESCE(SUM(delta),0) points FROM club_point_adjustments WHERE user_id=?',uid)]);
  const demoMode=demoPoints>0;const realStock=Object.fromEntries(REWARDS.map(r=>[r.id,data[0].results.find(x=>x.id===r.id)?.stock||0]));
  const stock=demoMode?Object.fromEntries(REWARDS.map(r=>[r.id,Math.max(0,10-data[2].results.filter(x=>x.id.startsWith('DEMO-')&&x.reward_id===r.id).length)])):realStock;
  return result({admin,email,adjustmentPoints:data[4].results[0].points,profile:data[3].results[0]||null,demoPoints,demoMode,rewards:REWARDS,stock,realStock:admin?realStock:undefined,activations:data[1].results,redemptions:data[2].results});
 }
 if(path==='/api/ranking'&&req.method==='GET'){
  const rows=await q(`WITH earned AS (SELECT user_id,SUM(earned) earned FROM (SELECT used_by user_id,COUNT(*) earned FROM club_keys WHERE used_by IS NOT NULL GROUP BY used_by UNION ALL SELECT user_id,SUM(delta) earned FROM club_point_adjustments GROUP BY user_id) GROUP BY user_id), spent AS (SELECT user_id,SUM(cost) spent FROM club_redemptions WHERE status!='demo' GROUP BY user_id), scores AS (SELECT p.user_id,p.full_name,f.photo,e.earned,MAX(0,e.earned-COALESCE(s.spent,0)) points FROM club_profiles p JOIN earned e ON e.user_id=p.user_id LEFT JOIN spent s ON s.user_id=p.user_id LEFT JOIN club_profile_photos f ON f.user_id=p.user_id WHERE NOT EXISTS(SELECT 1 FROM club_redemptions d WHERE d.user_id=p.user_id AND d.status='demo') AND p.user_id!=?), ranked AS (SELECT *,RANK() OVER(ORDER BY points DESC) position FROM scores WHERE points>0) SELECT * FROM ranked ORDER BY points DESC,earned DESC,user_id`,admin?uid:'').all();
  const publicRow=r=>({name:r.full_name.trim().split(/\s+/).map((n,i)=>i===0?n:n[0]+'.').join(' '),photo:r.photo||null,points:r.points,position:r.position,isYou:r.user_id===uid});
  let entries=rows.results.map(publicRow);
  if(demoPoints>0){
   const demo=await q(`SELECT p.full_name,f.photo,${used}+?-${spent} points FROM club_profiles p LEFT JOIN club_profile_photos f ON f.user_id=p.user_id WHERE p.user_id=?`,uid,demoPoints,uid,uid).all();
   const profile=demo.results[0];
   if(profile){entries=entries.filter(r=>!r.isYou);entries.push({name:profile.full_name.trim().split(/\s+/).map((n,i)=>i===0?n:n[0]+'.').join(' '),photo:profile.photo||null,points:Math.max(0,profile.points),isYou:true,demo:true});entries.sort((a,b)=>b.points-a.points);let position=0;entries=entries.map((r,i)=>{if(i===0||r.points!==entries[i-1].points)position=i+1;return {...r,position}});}
  }
  return result({leaders:entries.slice(0,50),you:entries.find(r=>r.isYou)||null,total:entries.length,demoPreview:demoPoints>0,updatedAt:new Date().toISOString()});
 }
 if(path==='/api/profile/photo'&&req.method==='POST'){
  const profile=await q('SELECT user_id FROM club_profiles WHERE user_id=?',uid).all();if(!profile.results.length)return fail('Salve seu cadastro antes de adicionar uma foto.',412);
  if(body.photo===null){await q('DELETE FROM club_profile_photos WHERE user_id=?',uid).run();return result({message:'Foto removida.'});}
  const photo=String(body.photo||''),match=/^data:image\/(jpeg|png|webp);base64,([A-Za-z0-9+/]+={0,2})$/.exec(photo);
  if(!match||photo.length>140000)return fail('Escolha uma foto JPG, PNG ou WebP de até 100 KB após o ajuste.');
  let bytes;try{bytes=Uint8Array.from(atob(match[2]),c=>c.charCodeAt(0))}catch{return fail('Foto inválida.');}
  const valid=match[1]==='jpeg'?bytes[0]===255&&bytes[1]===216&&bytes[2]===255:match[1]==='png'?bytes.slice(0,8).join(',')==='137,80,78,71,13,10,26,10':String.fromCharCode(...bytes.slice(0,4))==='RIFF'&&String.fromCharCode(...bytes.slice(8,12))==='WEBP';
  if(!valid||bytes.length>102400)return fail('Arquivo de foto inválido ou muito grande.');
  await q('INSERT INTO club_profile_photos(user_id,photo,updated_at) VALUES(?,?,?) ON CONFLICT(user_id) DO UPDATE SET photo=excluded.photo,updated_at=excluded.updated_at',uid,photo,new Date().toISOString()).run();
  return result({message:'Foto atualizada!'});
 }
 if(path==='/api/profile'&&req.method==='POST'){
  const name=String(body.name||'').trim(),contactEmail=String(body.email||'').trim().toLowerCase(),phone=String(body.phone||'').trim();
  if(name.length<2||name.length>100||/[\x00-\x1f]/.test(name))return fail('Informe seu nome, com 2 a 100 caracteres.');
  if(contactEmail.length>254||!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(contactEmail))return fail('Informe um e-mail válido.');
  if(phone&&(phone.length>30||!/^[+()\d\s.-]+$/.test(phone)||phone.replace(/\D/g,'').length<10||phone.replace(/\D/g,'').length>15))return fail('Informe um telefone válido com DDD, ou deixe em branco.');
  const now=new Date().toISOString();
  await q('INSERT INTO club_profiles(user_id,full_name,contact_email,phone,created_at,updated_at) VALUES(?,?,?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET full_name=excluded.full_name,contact_email=excluded.contact_email,phone=excluded.phone,updated_at=excluded.updated_at',uid,name,contactEmail,phone||null,now,now).run();
  return result({message:'Cadastro salvo! Você já pode solicitar seus resgates.'});
 }
 if(path==='/api/activate'&&req.method==='POST'){
  const code=String(body.code||'').trim().toUpperCase();if(!/^DG-(?:[A-F0-9]{8}-){3}[A-F0-9]{8}$/.test(code))return fail('Confira o código recebido e tente novamente.');
  const now=new Date().toISOString();const r=await q('UPDATE club_keys SET used_by = ?, used_email = ?, used_at = ? WHERE code = ? AND used_by IS NULL AND cancelled = 0 AND (expires_at IS NULL OR expires_at > ?) RETURNING code',uid,email,now,code,now).all();
  return r.results.length?result({message:'Código ativado! Você ganhou 1 ponto.'}):fail('Código inválido, vencido, cancelado ou já utilizado.');
 }
 if(path==='/api/redeem'&&req.method==='POST'){
  const reward=REWARDS.find(r=>r.id===body.reward);if(!reward)return fail('Brinde inválido.');
  if(!demoPoints){const profile=await q('SELECT user_id FROM club_profiles WHERE user_id = ?',uid).all();if(!profile.results.length)return fail('Complete seu cadastro com nome e e-mail antes de resgatar.',412);}
  const demoMode=demoPoints>0;const id=(demoMode?'DEMO-':'DG-')+crypto.randomUUID(),now=new Date().toISOString();
  if(demoMode){
   const r=await q(`INSERT INTO club_redemptions (id,user_id,email,reward_id,name,cost,created_at,status) SELECT ?,?,?,?,?,?,?,'demo' WHERE ${used} + ? - ${spent} >= ? AND (SELECT COUNT(*) FROM club_redemptions WHERE user_id = ? AND reward_id = ? AND id LIKE 'DEMO-%') < 10`,id,uid,email,reward.id,reward.name,reward.cost,now,uid,demoPoints,uid,reward.cost,uid,reward.id).run();
   return r.meta.changes?result({message:'Resgate de teste concluído! Nenhum brinde real foi consumido.',redemption:{id,name:reward.name,reward_id:reward.id,cost:reward.cost,created_at:now,status:'demo'}}):fail('Saldo de teste insuficiente ou limite de demonstração atingido.');
  }
  const batch=await db.batch([
   q(`INSERT INTO club_redemptions (id,user_id,email,reward_id,name,cost,created_at,status) SELECT ?,?,?,?,?,?,?,'pending' FROM club_rewards r WHERE r.id = ? AND r.stock > 0 AND ${used} + ? - ${spent} >= ?`,id,uid,email,reward.id,reward.name,reward.cost,now,reward.id,uid,demoPoints,uid,reward.cost),
   q('UPDATE club_rewards SET stock = stock - 1 WHERE id = ? AND EXISTS (SELECT 1 FROM club_redemptions WHERE id = ?)',reward.id,id)
  ]);
  return batch[0].meta.changes?result({message:'Brinde solicitado! Acompanhe em Meus resgates.',redemption:{id,name:reward.name,reward_id:reward.id,cost:reward.cost,created_at:now,status:'pending'}}):fail('Saldo insuficiente ou brinde sem estoque. Atualize e tente novamente.');
 }

 const customerBalanceSql=`SELECT p.user_id,p.full_name,p.contact_email,(SELECT COUNT(*) FROM club_keys k WHERE k.used_by=p.user_id)+COALESCE((SELECT SUM(delta) FROM club_point_adjustments a WHERE a.user_id=p.user_id),0)-COALESCE((SELECT SUM(cost) FROM club_redemptions r WHERE r.user_id=p.user_id AND r.status!='demo'),0) points FROM club_profiles p WHERE p.user_id=?`;
 if(path==='/api/admin/customer-points'&&req.method==='GET'){
  const target=(url.searchParams.get('user')||'').slice(0,200);const profile=(await q(customerBalanceSql,target).all()).results[0];if(!profile)return fail('Cliente não encontrado.',404);
  const history=await q('SELECT id,operation,delta,points_before,points_after,reason,admin_email,created_at FROM club_point_adjustments WHERE user_id=? ORDER BY created_at DESC,id DESC LIMIT 50',target).all();
  return result({customer:profile,history:history.results});
 }
 if(path==='/api/admin/customer-points'&&req.method==='POST'){
  const target=String(body.user||''),operation=body.operation,reason=String(body.reason||'').trim(),amount=body.amount,expected=body.expectedBalance,id=String(body.id||'');
  if(target.length>200||!['add','remove','reset'].includes(operation)||reason.length<3||reason.length>300||!Number.isSafeInteger(expected)||expected<0||expected>1000000||!/^[a-f0-9-]{36}$/i.test(id))return fail('Confira o cliente, a operação, o saldo e o motivo.');
  if(operation!=='reset'&&(!Number.isSafeInteger(amount)||amount<1||amount>100000))return fail('Informe de 1 a 100.000 pontos inteiros.');
  const previous=(await q('SELECT * FROM club_point_adjustments WHERE id=?',id).all()).results[0];
  if(previous){if(previous.admin_user_id===uid&&previous.user_id===target&&previous.operation===operation&&previous.reason===reason&&previous.points_before===expected&&previous.delta===(operation==='reset'?-expected:operation==='add'?amount:-amount))return result({message:'Esta alteração já foi aplicada.',adjustment:previous});return fail('Identificador de alteração já utilizado.',409)}
  const delta=operation==='reset'?-expected:operation==='add'?amount:-amount;
  if(expected+delta<0||expected+delta>1000000)return fail('O saldo deve ficar entre 0 e 1.000.000 de pontos.');
  const r=await q(`INSERT INTO club_point_adjustments(id,user_id,operation,delta,points_before,points_after,reason,admin_user_id,admin_email,created_at) SELECT ?,user_id,?,?,points,points+?,?,?,?,? FROM (${customerBalanceSql}) WHERE points=? RETURNING id,delta,points_before,points_after`,id,operation,delta,delta,reason,uid,email,new Date().toISOString(),target,expected).all();
  return r.results.length?result({message:'Pontos atualizados com sucesso.',adjustment:r.results[0]}):fail('O saldo mudou ou o cliente não existe. Atualize e confira antes de tentar novamente.',409);
 }
 if(path==='/api/admin/customers'&&req.method==='GET'){
  const page=Math.max(1,Math.min(1000000,parseInt(url.searchParams.get('page')||'1',10)||1)),limit=50,search=(url.searchParams.get('search')||'').trim().slice(0,100),hasSearch=search.length>0;
  const where=hasSearch?' WHERE p.full_name LIKE ? OR p.contact_email LIKE ? OR p.phone LIKE ?':'',args=hasSearch?Array(3).fill('%'+search+'%'):[];
  const join=` FROM club_profiles p LEFT JOIN club_profile_photos f ON f.user_id=p.user_id LEFT JOIN (SELECT used_by,COUNT(*) earned FROM club_keys WHERE used_by IS NOT NULL GROUP BY used_by) k ON k.used_by=p.user_id LEFT JOIN (SELECT user_id,COUNT(*) redemptions,SUM(CASE WHEN status!='demo' THEN cost ELSE 0 END) spent FROM club_redemptions GROUP BY user_id) r ON r.user_id=p.user_id LEFT JOIN (SELECT user_id,SUM(delta) adjustment FROM club_point_adjustments GROUP BY user_id) a ON a.user_id=p.user_id`;
  const data=await db.batch([q('SELECT p.user_id,p.full_name,p.contact_email,p.phone,p.created_at,p.updated_at,f.photo,COALESCE(k.earned,0) earned,COALESCE(a.adjustment,0) adjustment,MAX(0,COALESCE(k.earned,0)+COALESCE(a.adjustment,0)-COALESCE(r.spent,0)) points,COALESCE(r.redemptions,0) redemptions'+join+where+' ORDER BY p.created_at DESC,p.user_id LIMIT ? OFFSET ?',...args,limit,(page-1)*limit),q('SELECT COUNT(*) total FROM club_profiles p'+where,...args),q('SELECT COUNT(*) total,COALESCE(SUM(CASE WHEN EXISTS(SELECT 1 FROM club_redemptions r WHERE r.user_id=p.user_id) THEN 1 ELSE 0 END),0) withRedemptions FROM club_profiles p')]);
  return result({customers:data[0].results,total:data[1].results[0].total,page,pageSize:limit,summary:data[2].results[0]});
 }
 if(path==='/api/admin/data'&&req.method==='GET'){
  const r=await db.batch([q('SELECT * FROM club_keys ORDER BY created_at DESC LIMIT 2000'),q('SELECT r.*,p.full_name,p.contact_email,p.phone FROM club_redemptions r LEFT JOIN club_profiles p ON p.user_id=r.user_id ORDER BY r.created_at DESC LIMIT 1000')]);return result({keys:r[0].results,requests:r[1].results});
 }
 if(path==='/api/admin/requests'&&req.method==='GET'){
  const page=Math.max(1,Math.min(1000000,Number.parseInt(url.searchParams.get('page')||'1',10)||1)),limit=50;
  const search=(url.searchParams.get('search')||'').trim().slice(0,100),status=url.searchParams.get('status')||'all';
  if(!['all','pending','delivered','demo'].includes(status))return fail('Filtro inválido.');
  const clauses=[],args=[];
  if(search){clauses.push('(p.full_name LIKE ? OR p.contact_email LIKE ? OR p.phone LIKE ? OR r.email LIKE ? OR r.name LIKE ? OR r.id LIKE ?)');for(let i=0;i<6;i++)args.push('%'+search+'%');}
  if(status!=='all'){clauses.push('r.status = ?');args.push(status);}
  const join=' FROM club_redemptions r LEFT JOIN club_profiles p ON p.user_id=r.user_id',where=clauses.length?' WHERE '+clauses.join(' AND '):'';
  const data=await db.batch([q('SELECT r.*,p.full_name,p.contact_email,p.phone'+join+where+' ORDER BY r.created_at DESC,r.id DESC LIMIT ? OFFSET ?',...args,limit,(page-1)*limit),q('SELECT COUNT(*) total'+join+where,...args),q("SELECT COUNT(DISTINCT user_id) clients,COUNT(*) requests,COALESCE(SUM(CASE WHEN status='pending' THEN 1 ELSE 0 END),0) pending,COALESCE(SUM(CASE WHEN status='delivered' THEN 1 ELSE 0 END),0) delivered FROM club_redemptions")]);
  return result({requests:data[0].results,total:data[1].results[0].total,page,pageSize:limit,summary:data[2].results[0]});
 }
 if(path==='/api/admin/generate'&&req.method==='POST'){
  const count=Number(body.count),label=String(body.label||'').trim().slice(0,80);if(!Number.isInteger(count)||count<1||count>200)return fail('Gere entre 1 e 200 códigos por lote.');
  let expiry=null;if(body.expires){if(!/^\d{4}-\d{2}-\d{2}$/.test(body.expires))return fail('Validade inválida.');expiry=body.expires+'T23:59:59-03:00';if(!Number.isFinite(Date.parse(expiry))||Date.parse(expiry)<=Date.now())return fail('Escolha uma validade futura.');expiry=new Date(expiry).toISOString();}
  const batch=crypto.randomUUID(),created=new Date().toISOString(),codes=Array.from({length:count},random);
  await db.batch(codes.map(code=>q('INSERT INTO club_keys (code,batch_id,label,created_at,expires_at) VALUES (?,?,?,?,?)',code,batch,label,created,expiry)));
  return result({codes,message:count+' códigos gerados. Cada código vale 1 ponto.'});
 }
 if(path==='/api/admin/cancel'&&req.method==='POST'){
  const r=await q('UPDATE club_keys SET cancelled = 1 WHERE code = ? AND used_by IS NULL AND cancelled = 0',String(body.code)).run();return r.meta.changes?result({message:'Código cancelado.'}):fail('Este código já foi usado ou cancelado.');
 }
 if(path==='/api/admin/config'&&req.method==='POST'){
  if(REWARDS.some(r=>!Number.isInteger(body.stock?.[r.id])||body.stock[r.id]<0||body.stock[r.id]>10000))return fail('Informe estoques válidos.');
  await db.batch(REWARDS.map(r=>q('INSERT INTO club_rewards(id,stock) VALUES(?,?) ON CONFLICT(id) DO UPDATE SET stock = excluded.stock',r.id,body.stock[r.id])));return result({message:'Configurações salvas.'});
 }
 if(path==='/api/admin/deliver'&&req.method==='POST'){
  const r=await q("UPDATE club_redemptions SET status = 'delivered' WHERE id = ? AND status = 'pending'",String(body.id)).run();return r.meta.changes?result({message:'Entrega confirmada.'}):fail('Solicitação não encontrada ou já entregue.');
 }
 return fail('Operação não encontrada.',404);
 }catch(e){console.error('Club request failed',path,e.message);return fail('Não foi possível concluir. Atualize para conferir o resultado antes de tentar novamente.',500);}
}
