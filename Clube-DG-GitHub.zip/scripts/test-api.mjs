import {DatabaseSync} from 'node:sqlite';
import fs from 'node:fs';
import assert from 'node:assert/strict';
import {api} from '../worker/api.mjs';
import {REWARDS} from '../worker/catalog.mjs';
const CORE=REWARDS;
const sqlite=new DatabaseSync(':memory:');for(const file of fs.readdirSync('drizzle').filter(f=>f.endsWith('.sql')).sort())sqlite.exec(fs.readFileSync('drizzle/'+file,'utf8'));
for(const uid of ['owner','alice','bob',...REWARDS.map(r=>'boundary-'+r.id)])sqlite.prepare('INSERT INTO club_profiles VALUES(?,?,?,?,?,?)').run(uid,uid+' Name',uid+'@test.test',null,new Date().toISOString(),new Date().toISOString());
class Statement{constructor(sql,args=[]){this.sql=sql;this.args=args;}bind(...args){return new Statement(this.sql,args)}execute(){const s=sqlite.prepare(this.sql);if(s.columns().length){const results=s.all(...this.args);return {results,meta:{changes:Number(sqlite.prepare('SELECT changes() n').get().n)}}}const r=s.run(...this.args);return {results:[],meta:{changes:Number(r.changes)}}}async all(){return this.execute()}async run(){return this.execute()}}
const env={ADMIN_EMAIL:'owner@test.test',DB:{prepare:sql=>new Statement(sql),async batch(items){sqlite.exec('BEGIN');try{const r=items.map(s=>s.execute());sqlite.exec('COMMIT');return r}catch(e){sqlite.exec('ROLLBACK');throw e}}}};
const testSessions=new Map();
async function call(path,body,user='owner',email='owner@test.test',origin='https://test.test'){const headers={'oai-authenticated-user-id':user,'oai-authenticated-user-email':email};if(!testSessions.has(user)){const created=await api(new Request('https://test.test/api/security/create',{method:'POST',headers:{...headers,Origin:'https://test.test','Content-Type':'application/json'},body:JSON.stringify({password:'Testing-Password-987'})}),env);assert.equal(created.status,200);testSessions.set(user,created.headers.get('set-cookie').split(';')[0])}headers.Cookie=testSessions.get(user);if(body!==undefined){headers.Origin=origin;headers['Content-Type']='application/json'}const r=await api(new Request('https://test.test/api'+path,{method:body===undefined?'GET':'POST',headers,body:body===undefined?undefined:JSON.stringify(body)}),env);return {status:r.status,...await r.json()}}
const anonymousState=await api(new Request('https://test.test/api/state'),env);assert.equal(anonymousState.status,200);const anonymous=await anonymousState.json();assert(anonymous.guest);assert(!anonymous.admin);assert.equal(anonymous.demoPoints,0);assert.equal(anonymous.profile,null);assert.equal(anonymous.redemptions.length,0);
for(const path of ['/api/admin/data','/api/ranking'])assert.equal((await api(new Request('https://test.test'+path),env)).status,401);
assert.equal((await api(new Request('https://test.test/api/redeem',{method:'POST',headers:{origin:'https://test.test','content-type':'application/json'},body:JSON.stringify({reward:'netflix'})}),env)).status,401);
assert.equal((await call('/admin/data',undefined,'alice','alice@test.test')).status,403);
assert.equal((await call('/admin/generate',{count:1},'owner','owner@test.test','https://evil.test')).status,403);
assert.equal((await call('/admin/generate',{count:201})).status,400);
assert.equal((await call('/admin/config',{stock:Object.fromEntries(REWARDS.map(r=>[r.id,1]))})).status,200);
const lot=await call('/admin/generate',{count:30,label:'Test'});assert.equal(lot.codes.length,30);assert.equal(new Set(lot.codes).size,30);
assert.equal((await call('/activate',{code:lot.codes[0]},'alice','alice@test.test')).status,200);
const raced=await Promise.all([call('/activate',{code:lot.codes[0]},'bob','bob@test.test'),call('/activate',{code:lot.codes[0]},'alice','alice@test.test')]);assert(raced.every(r=>r.status===400));
assert.equal((await call('/activate',{code:lot.codes[1]},'alice','alice@test.test')).status,200);
const st=await call('/state',undefined,'alice','alice@test.test');assert.equal(st.activations.length,2);assert.equal(st.redemptions.length,0);
assert.equal((await call('/state',undefined,'bob','bob@test.test')).activations.length,0);
assert.equal((await call('/admin/cancel',{code:lot.codes[0]})).status,400);
assert.equal((await call('/admin/cancel',{code:lot.codes[2]})).status,200);
assert.equal((await call('/activate',{code:lot.codes[2]},'alice','alice@test.test')).status,400);
for(const code of lot.codes.slice(3,21))assert.equal((await call('/activate',{code},'bob','bob@test.test')).status,200);
for(const code of lot.codes.slice(21))assert.equal((await call('/activate',{code},'alice','alice@test.test')).status,200);
// Alice has 11 points, Bob 18: Alice cannot redeem Netflix even if she sends a forged price.
assert.equal((await call('/redeem',{reward:'netflix',cost:1},'alice','alice@test.test')).status,400);
// Alice redeems the discount for exactly 8, leaving 3 points.
assert.equal((await call('/redeem',{reward:'prime',cost:1},'alice','alice@test.test')).status,200);
const redeemed=await Promise.all([call('/redeem',{reward:'netflix'},'alice','alice@test.test'),call('/redeem',{reward:'netflix'},'bob','bob@test.test')]);assert.equal(redeemed.filter(r=>r.status===200).length,1);assert.equal((await call('/state')).stock.netflix,0);
assert.equal((await call('/redeem',{reward:'prime'},'alice','alice@test.test')).status,400);
const first=(await call('/state',undefined,'alice','alice@test.test')).redemptions[0];assert.equal(first.cost,8);assert.equal((await call('/admin/deliver',{id:first.id})).status,200);assert.equal((await call('/admin/deliver',{id:first.id})).status,400);
const expired=(await call('/admin/generate',{count:1})).codes[0];sqlite.prepare('UPDATE club_keys SET expires_at = ? WHERE code = ?').run('2020-01-01T00:00:00.000Z',expired);assert.equal((await call('/activate',{code:expired},'alice','alice@test.test')).status,400);
assert.deepEqual(CORE.slice(0,15).map(r=>[r.name,r.cost]),[['Globoplay',15],['Netflix',18],['Spotify',13],['Prime Video',8],['YouTube Premium',10],['HBO Max',15],['F1 TV Premium',14],['Disney+ Premium',10],['Sky+ Premium',31],['Premiere Play',10],['NBA League Pass',16],['Viki Rakuten',8],['Crunchyroll',14],['Game Pass Ultimate',26],['PlayStation Plus Deluxe',16]]);
assert.equal((await call('/state',undefined,'bob','bob@test.test')).redemptions[0].cost,18);
// Each reward rejects a balance below its price and debits its exact server price.
for(const reward of CORE){
 const uid='boundary-'+reward.id;
 sqlite.prepare('UPDATE club_rewards SET stock=1 WHERE id=?').run(reward.id);
 for(let n=0;n<reward.cost-1;n++)sqlite.prepare('INSERT INTO club_keys(code,batch_id,label,created_at,used_by,used_email,used_at) VALUES(?,?,?,?,?,?,?)').run(uid+'-'+n,'boundary','test',new Date().toISOString(),uid,uid+'@test.test',new Date().toISOString());
 assert.equal((await call('/redeem',{reward:reward.id,cost:0},uid,uid+'@test.test')).status,400);
 sqlite.prepare('INSERT INTO club_keys(code,batch_id,label,created_at,used_by,used_email,used_at) VALUES(?,?,?,?,?,?,?)').run(uid+'-last','boundary','test',new Date().toISOString(),uid,uid+'@test.test',new Date().toISOString());
 assert.equal((await call('/redeem',{reward:reward.id,cost:0},uid,uid+'@test.test')).status,200);
 const snapshot=await call('/state',undefined,uid,uid+'@test.test');assert.equal(snapshot.redemptions[0].cost,reward.cost);assert.equal(snapshot.activations.length-snapshot.redemptions[0].cost,0);
}
console.log('Passed: exact price and insufficient-balance boundary for all 108 rewards; forged client cost ignored.');
console.log('Passed: identity, admin authorization, origin, batch validation, unique keys, use-once across accounts, isolated balances, cancellation, expiry, atomic last-stock redemption, points debit, delivery.');

// Demo credit belongs only to the administrator and is debited normally.
env.DEMO_POINTS='100';
assert.equal((await call('/state')).demoPoints,100);
assert.equal((await call('/state',undefined,'bob','bob@test.test')).demoPoints,0);
sqlite.prepare('UPDATE club_rewards SET stock=1 WHERE id=?').run('netflix');
assert.equal((await call('/redeem',{reward:'netflix'})).status,200);
const demo=await call('/state');assert.equal(demo.activations.length+demo.demoPoints-demo.redemptions.reduce((a,r)=>a+r.cost,0),82);
sqlite.prepare('UPDATE club_rewards SET stock=1 WHERE id=?').run('prime');
assert.equal((await call('/redeem',{reward:'prime',demoPoints:100},'bob','bob@test.test')).status,400);
console.log('Passed: 100 demo points exclusive to administrator; server debit and customer isolation.');
// The demo account can test all rewards even when the real stock is empty.
sqlite.prepare('UPDATE club_rewards SET stock=0').run();
env.DEMO_POINTS='10000';
const demoUser='demo-stock-test';
const before=await call('/state',undefined,demoUser,'owner@test.test');
assert(REWARDS.every(r=>before.stock[r.id]===10&&before.realStock[r.id]===0));
for(const reward of CORE)assert.equal((await call('/redeem',{reward:reward.id},demoUser,'owner@test.test')).status,200);
const after=await call('/state',undefined,demoUser,'owner@test.test');
assert.equal(after.demoPoints-after.redemptions.reduce((n,r)=>n+r.cost,0),10000-CORE.reduce((n,r)=>n+r.cost,0));
assert.equal(after.redemptions.length,108);assert(after.redemptions.every(r=>r.status==='demo'&&r.id.startsWith('DEMO-')));
assert(CORE.every(r=>after.stock[r.id]===9&&after.realStock[r.id]===0));
assert.equal((await call('/admin/deliver',{id:after.redemptions[0].id})).status,400);
const customerState=await call('/state',undefined,'bob','bob@test.test');assert(REWARDS.every(r=>customerState.stock[r.id]===0));
console.log('Passed: all 108 demo rewards with zero real stock, exact catalog-point debit, unchanged customer stock, no delivery for simulations.');

// Registration validates required fields and keeps each profile attached to its authenticated owner.
assert.equal((await call('/profile',{name:'A',email:'bad'},'new','new@test.test')).status,400);
assert.equal((await call('/profile',{name:'New Client',email:'a@b@c.test'},'new','new@test.test')).status,400);
assert.equal((await call('/profile',{name:'New Client',email:'new@test.test',phone:'123'},'new','new@test.test')).status,400);
assert.equal((await call('/redeem',{reward:'prime'},'new','new@test.test')).status,412);
assert.equal((await call('/profile',{name:'New Client',email:'contact@test.test',phone:'',user_id:'alice'},'new','new@test.test')).status,200);
let profile=(await call('/state',undefined,'new','new@test.test')).profile;assert.equal(profile.full_name,'New Client');assert.equal(profile.phone,null);assert.equal(profile.contact_email,'contact@test.test');
assert.equal((await call('/state',undefined,'alice','alice@test.test')).profile.full_name,'alice Name');
assert.equal((await call('/profile',{name:'New Client',email:'owner@test.test',phone:'(75) 99999-9999'},'new','new@test.test')).status,200);
assert.equal((await call('/state',undefined,'new','new@test.test')).admin,false);
assert.equal((await call('/admin/requests',undefined,'new','new@test.test')).status,403);
const contacts=await call('/admin/requests?search=alice&status=delivered');assert.equal(contacts.status,200);assert(contacts.requests.every(r=>r.user_id==='alice'&&r.status==='delivered'));assert.equal(contacts.requests[0].full_name,'alice Name');
const empty=await call('/admin/requests?search=missing-unique-client');assert.equal(empty.total,0);
// All requests are reachable through pagination, including those without a legacy profile.
const stamp=new Date().toISOString();sqlite.prepare('INSERT INTO club_profiles VALUES(?,?,?,?,?,?)').run('pager','Pagination Client','pager@test.test','(75) 99999-1111',stamp,stamp);
for(let i=0;i<55;i++)sqlite.prepare('INSERT INTO club_redemptions(id,user_id,email,reward_id,name,cost,created_at,status) VALUES(?,?,?,?,?,?,?,?)').run('PAGE-'+i,'pager','pager@test.test','prime','Prime Video',8,stamp,'pending');
const pg1=await call('/admin/requests?search=Pagination&page=1'),pg2=await call('/admin/requests?search=Pagination&page=2');assert.equal(pg1.total,55);assert.equal(pg1.requests.length,50);assert.equal(pg2.requests.length,5);assert.equal(new Set([...pg1.requests,...pg2.requests].map(r=>r.id)).size,55);assert(pg1.requests.every(r=>r.phone==='(75) 99999-1111'));
assert.equal((await call('/admin/requests?status=bad')).status,400);
console.log('Passed: registration, optional phone, validation, self-only profile updates, profile requirement for real redemptions, admin contact access, filtering, and complete pagination.');

assert.equal(REWARDS.length,108);assert.equal(new Set(REWARDS.map(r=>r.id)).size,108);assert(REWARDS.every(r=>r.art&&!r.coverArt&&!r.art.includes('dgshop.com.br/cdn')));
for(const removed of ['removed-game'])assert.equal((await call('/redeem',{reward:removed})).status,400);
assert.deepEqual(Object.keys((await call('/state')).stock),REWARDS.map(r=>r.id));
console.log('Passed: exactly 108 active rewards, preserved points and original logos, removed rewards blocked on server.');

assert.equal(REWARDS.filter(r=>r.catalogGroup==='steam').length,70);assert.deepEqual(REWARDS.filter(r=>r.category==='ai').slice(0,4).map(r=>[r.name,r.cost]),[['ChatGPT Plus',10],['Claude Code IA',39],['Manus IA Pro',16],['Grok Premium',19]]);
// Ranking uses server-owned real balances, preserves ties and never returns contacts or IDs.
for(const [id,name,points] of [['rank-a','Ana Santos',12],['rank-b','Bruno Silva',12],['rank-c','Carla Souza',8],['rank-demo','Demo Pessoa',90]]){
 sqlite.prepare('INSERT INTO club_profiles VALUES(?,?,?,?,?,?)').run(id,name,id+'@test.test','75999999999',stamp,stamp);
 for(let n=0;n<points;n++)sqlite.prepare('INSERT INTO club_keys(code,batch_id,label,created_at,used_by,used_email,used_at) VALUES(?,?,?,?,?,?,?)').run(id+'-'+n,'ranking','ranking',stamp,id,id+'@test.test',stamp);
}
sqlite.prepare('INSERT INTO club_redemptions VALUES(?,?,?,?,?,?,?,?)').run('rank-spent','rank-c','rank-c@test.test','prime','Prime',8,stamp,'delivered');
sqlite.prepare('INSERT INTO club_redemptions VALUES(?,?,?,?,?,?,?,?)').run('DEMO-rank','rank-demo','rank-demo@test.test','prime','Prime',8,stamp,'demo');
const rank=await call('/ranking',undefined,'rank-a','rank-a@test.test');
assert.equal(rank.you.points,12);assert(rank.you.isYou);const ana=rank.leaders.find(r=>r.name==='Ana S.'),bruno=rank.leaders.find(r=>r.name==='Bruno S.');assert.equal(ana.position,bruno.position);assert(!rank.leaders.some(r=>r.name==='Carla S.'||r.name==='Demo P.'));
assert(!JSON.stringify(rank).includes('@'));assert(!JSON.stringify(rank).includes('75999999999'));assert(!JSON.stringify(rank).includes('rank-a'));
console.log('Passed: ranking real balances, redeemed-points subtraction, tied positions, demo exclusion and contact privacy.');
// Admin role is based on verified sign-in email, never editable profile contact.
env.ADMIN_EMAILS='nvsdgo@gmail.com,marcosplays007@gmail.com';env.DEMO_POINTS='10000';
for(const mail of ['nvsdgo@gmail.com','marcosplays007@gmail.com']){const s=await call('/state',undefined,'admin-'+mail,mail);assert(s.admin);assert.equal(s.demoPoints,10000);assert.equal((await call('/admin/generate',{count:1},'admin-'+mail,mail)).status,200)}
assert.equal((await call('/state',undefined,'owner','owner@test.test')).admin,false);assert.equal((await call('/admin/generate',{count:1},'alice','alice@test.test')).status,403);
const tiny='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aV1cAAAAASUVORK5CYII=';
assert.equal((await call('/profile/photo',{photo:tiny},'alice','alice@test.test')).status,200);assert.equal((await call('/state',undefined,'alice','alice@test.test')).profile.photo,tiny);assert.equal((await call('/state',undefined,'bob','bob@test.test')).profile.photo,null);
assert.equal((await call('/profile/photo',{photo:'data:image/svg+xml;base64,PHN2Zz4='},'alice','alice@test.test')).status,400);assert.equal((await call('/profile/photo',{photo:'data:image/png;base64,YWJjZA=='},'alice','alice@test.test')).status,400);
assert.equal((await call('/profile/photo',{photo:null},'alice','alice@test.test')).status,200);assert.equal((await call('/state',undefined,'alice','alice@test.test')).profile.photo,null);
console.log('Passed: two verified-email demo admins, contact-independent authorization, private photo persistence/removal and invalid format rejection.');
assert.equal((await call('/profile/photo',{photo:tiny},'rank-a','rank-a@test.test')).status,200);
const withPhoto=await call('/ranking',undefined,'rank-a','rank-a@test.test');assert.equal(withPhoto.you.photo,tiny);assert.equal(withPhoto.leaders.find(r=>r.name==='Bruno S.').photo,null);
const additions=['Deezer Premium','Amazon Music','NFL Game Pass','Paramount+ Premium','Strava Premium','Claro TV+ Premiere','Tidal Music','Passe Booyah Premium Free Fire'];assert(additions.every(name=>REWARDS.some(r=>r.name===name)));assert.equal(REWARDS.find(r=>r.name==='Amazon Music').duration,'3 meses de acesso');
console.log('Passed: ranking photos and initials fallback data, eight new products and Amazon Music three-month duration.');
// An administrator sees their own demonstration entry with the same remaining balance as state.
const demoMail='nvsdgo@gmail.com',demoUid='ranking-demo-owner';
await call('/profile',{name:'Diego Demo',email:demoMail},demoUid,demoMail);
const beforeDemoRank=await call('/ranking',undefined,demoUid,demoMail);assert(beforeDemoRank.you.demo);assert.equal(beforeDemoRank.you.points,10000);assert.equal(beforeDemoRank.you.position,1);
assert.equal((await call('/redeem',{reward:'netflix'},demoUid,demoMail)).status,200);
const afterDemoRank=await call('/ranking',undefined,demoUid,demoMail);assert.equal(afterDemoRank.you.points,9982);assert(afterDemoRank.you.demo);assert(afterDemoRank.demoPreview);
const normalRank=await call('/ranking',undefined,'rank-a','rank-a@test.test');assert(!normalRank.demoPreview);assert(!normalRank.leaders.some(r=>r.demo||r.name==='Diego D.'));
console.log('Passed: private demo ranking entry, exact post-redemption balance, demonstration label and customer ranking isolation.');
const latest=[['CapCut Pro',6],['Apple TV',5],['Lumine TV',7],['Perplexity IA Pro',16],['Darkflix',4],['Magnific AI Premium',16],['NordVPN',9],['Amazon Kindle',3],['KOCOWA+',3],['iQIYI',4]];
assert(latest.every(([name,cost])=>REWARDS.some(r=>r.name===name&&r.cost===cost)));assert.equal(REWARDS.find(r=>r.name==='Amazon Kindle').duration,'3 meses de acesso');
for(const [name] of latest){const reward=REWARDS.find(r=>r.name===name);assert(fs.existsSync('web/assets/'+reward.art));assert(reward.assetSource.startsWith('https://'))}
assert(REWARDS.find(r=>r.name==='Amazon Kindle').art!=='original-amazon-com.png');assert(fs.readFileSync('web/assets/sky-mark.svg','utf8').includes('#e00022'));
console.log('Passed: ten new rewards, original local brand assets, red Sky mark and Kindle-specific artwork.');

const forcedDemo=await call('/state?demo=1');assert(forcedDemo.guest);assert(!forcedDemo.admin);assert.equal(forcedDemo.demoPoints,0);console.log('Passed: public demo bootstrap without personal records; anonymous API mutations/admin/ranking blocked; explicit client preview has no admin role.');
env.PUBLIC_DEMO='true';
const publicCustomer=await call('/state',undefined,'alice','alice@test.test');assert(publicCustomer.guest);assert(!publicCustomer.admin);assert.equal(publicCustomer.profile,null);
assert.equal((await call('/ranking',undefined,'alice','alice@test.test')).status,403);assert.equal((await call('/activate',{code:'DG-TESTE-0001'},'alice','alice@test.test')).status,403);assert.equal((await call('/redeem',{reward:'netflix'},'alice','alice@test.test')).status,403);
const publicAdmin=await call('/state',undefined,demoUid,demoMail);assert(publicAdmin.admin);assert(!publicAdmin.guest);
console.log('Passed: public testing mode keeps signed-in visitors in isolated demo and preserves only verified admin access.');
for(let i=0;i<55;i++)sqlite.prepare('INSERT INTO club_profiles VALUES(?,?,?,?,?,?)').run('directory-'+i,'Directory Cliente '+i,'directory-'+i+'@test.test',i===0?'75912345678':null,stamp,stamp);
const directory1=await call('/admin/customers?search=Directory&page=1',undefined,demoUid,demoMail),directory2=await call('/admin/customers?search=Directory&page=2',undefined,demoUid,demoMail);
assert.equal(directory1.total,55);assert.equal(directory1.customers.length,50);assert.equal(directory2.customers.length,5);assert(directory1.customers.every(c=>c.redemptions===0&&c.points===0));assert.equal(directory1.summary.total,sqlite.prepare('SELECT COUNT(*) n FROM club_profiles').get().n);
const phoneCustomer=await call('/admin/customers?search=75912345678',undefined,demoUid,demoMail);assert.equal(phoneCustomer.total,1);assert.equal(phoneCustomer.customers[0].full_name,'Directory Cliente 0');assert.equal((await call('/admin/customers',undefined,'alice','alice@test.test')).status,403);
console.log('Passed: all registered customers including zero-redemption profiles, 50-row pagination, contact search, counts and admin-only access.');

assert.equal(REWARDS.find(r=>r.id==='discount50').cost,1);
// Password protection: direct API requests, independent of browser logic.
async function secureCall(path,body,cookie='',uid='security-qa',origin='https://test.test'){
 const r=await api(new Request('https://test.test/api'+path,{method:body===undefined?'GET':'POST',headers:{'oai-authenticated-user-id':uid,'oai-authenticated-user-email':'security@example.test',Cookie:cookie,Origin:origin,'Content-Type':'application/json'},body:body===undefined?undefined:JSON.stringify(body)}),env);return {status:r.status,cookie:r.headers.get('set-cookie'),body:await r.json()};
}
assert.equal((await secureCall('/security')).body.stage,'create');
assert.equal((await secureCall('/state')).status,423);
assert.equal((await secureCall('/admin/data?demo=1')).status,423);
assert.equal((await secureCall('/security/create',{password:'short'})).status,400);
assert.equal((await secureCall('/security/create',{password:'Strong-Testing-765'},'','security-qa','https://evil.test')).status,403);
const secured=await secureCall('/security/create',{password:'Strong-Testing-765'});assert.equal(secured.status,200);assert(secured.cookie.includes('HttpOnly; Secure; SameSite=Strict'));const sessionCookie=secured.cookie.split(';')[0];
assert.equal((await secureCall('/security',undefined,sessionCookie)).body.stage,'ready');
assert.equal((await secureCall('/security',undefined,sessionCookie,'someone-else')).body.stage,'create');
assert.equal((await secureCall('/security/create',{password:'Replace-Testing-765'})).status,409);
await secureCall('/security/logout',{},sessionCookie);assert.equal((await secureCall('/state',undefined,sessionCookie)).status,423);
for(let n=0;n<5;n++)assert.equal((await secureCall('/security/unlock',{password:'wrong'})).status,401);
assert.equal((await secureCall('/security/unlock',{password:'Strong-Testing-765'})).status,429);
sqlite.prepare('UPDATE club_passwords SET locked_until=? WHERE user_id=?').run(Date.now()-1,'security-qa');
const unlocked=await secureCall('/security/unlock',{password:'Strong-Testing-765'});assert.equal(unlocked.status,200);const unlockedCookie=unlocked.cookie.split(';')[0];
sqlite.prepare('UPDATE club_sessions SET expires_at=0 WHERE user_id=?').run('security-qa');assert.equal((await secureCall('/state',undefined,unlockedCookie)).status,423);
const stored=sqlite.prepare('SELECT * FROM club_passwords WHERE user_id=?').get('security-qa');assert.equal(stored.password_hash.length,64);assert(!JSON.stringify(stored).includes('Strong-Testing-765'));
console.log('Passed: password hashing, server-side account gate, session cookies, identity binding, CSRF, single setup, five-attempt lockout, expiry and logout revocation.');
// Administrators manage real balances through an append-only adjustment ledger.
env.PUBLIC_DEMO='false';env.DEMO_POINTS='0';
const pointsTarget='directory-0';
const pointCommand=(operation,amount,expectedBalance,reason='Ajuste de teste')=>({id:crypto.randomUUID(),user:pointsTarget,operation,amount,expectedBalance,reason});
const firstPoints=pointCommand('add',20,0);
assert.equal((await call('/admin/customer-points',firstPoints,demoUid,demoMail)).status,200);
assert.equal((await call('/admin/customer-points',firstPoints,demoUid,demoMail)).status,200);
let pointState=await call('/state',undefined,pointsTarget,'directory-0@test.test');assert.equal(pointState.adjustmentPoints,20);
assert.equal((await call('/ranking',undefined,pointsTarget,'directory-0@test.test')).you.points,20);
const otherAdminMail='marcosplays007@gmail.com',otherAdminUid='admin-'+otherAdminMail;
assert.equal((await call('/admin/customer-points',pointCommand('remove',5,20),otherAdminUid,otherAdminMail)).status,200);
assert.equal((await call('/admin/customer-points',pointCommand('remove',16,15),demoUid,demoMail)).status,400);
assert.equal((await call('/admin/customer-points',pointCommand('add',1,20),demoUid,demoMail)).status,409);
assert.equal((await call('/redeem',{reward:'netflix'},pointsTarget,'directory-0@test.test')).status,400);
sqlite.prepare('INSERT INTO club_rewards(id,stock) VALUES(?,5) ON CONFLICT(id) DO UPDATE SET stock=5').run('prime');
assert.equal((await call('/redeem',{reward:'prime'},pointsTarget,'directory-0@test.test')).status,200);
assert.equal((await call('/admin/customer-points?user='+pointsTarget,undefined,demoUid,demoMail)).customer.points,7);
assert.equal((await call('/admin/customer-points',pointCommand('reset',0,7),otherAdminUid,otherAdminMail)).status,200);
pointState=await call('/state',undefined,pointsTarget,'directory-0@test.test');assert.equal(pointState.activations.length+pointState.adjustmentPoints-pointState.redemptions.reduce((n,r)=>n+r.cost,0),0);assert.equal(pointState.redemptions.length,1);
assert.equal((await call('/ranking',undefined,pointsTarget,'directory-0@test.test')).you,null);
const concurrent=await Promise.all([call('/admin/customer-points',pointCommand('add',10,0),demoUid,demoMail),call('/admin/customer-points',pointCommand('add',10,0),otherAdminUid,otherAdminMail)]);assert.deepEqual(concurrent.map(r=>r.status).sort(),[200,409]);
assert.equal((await call('/admin/customers?search=directory-0@test.test',undefined,demoUid,demoMail)).customers[0].points,10);
const audit=await call('/admin/customer-points?user='+pointsTarget,undefined,demoUid,demoMail);assert.equal(audit.history.length,4);assert(audit.history.some(h=>h.admin_email===demoMail));assert(audit.history.some(h=>h.admin_email===otherAdminMail));assert(audit.history.every(h=>h.reason==='Ajuste de teste'));
assert.equal((await call('/admin/customer-points',pointCommand('add',10,10),'alice','alice@test.test')).status,403);
assert.equal((await call('/admin/customer-points?user='+pointsTarget,undefined,'alice','alice@test.test')).status,403);
assert.equal((await call('/admin/customer-points',pointCommand('add',0.5,10),demoUid,demoMail)).status,400);
assert.equal((await call('/admin/customer-points',pointCommand('add',2,10,''),demoUid,demoMail)).status,400);
const protectedKey=(await call('/admin/generate',{count:1},demoUid,demoMail)).codes[0];assert.equal((await call('/activate',{code:protectedKey},pointsTarget,'directory-0@test.test')).status,200);
assert.equal((await call('/admin/customer-points',pointCommand('reset',0,11),demoUid,demoMail)).status,200);assert.equal((await call('/activate',{code:protectedKey},pointsTarget,'directory-0@test.test')).status,400);
console.log('Passed: both Gmail admins add/remove/reset points; customer balance, ranking, directory and redemption agree; immutable audit, idempotency, concurrent conflict, authorization and used-code preservation.');
