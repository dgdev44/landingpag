// Development preview only. Uses synthetic records and an in-memory database.
import http from 'node:http';
import fs from 'node:fs';
import {DatabaseSync} from 'node:sqlite';
import worker from '../dist/server/index.js';
const db=new DatabaseSync(':memory:');
for(const file of fs.readdirSync('drizzle').filter(f=>f.endsWith('.sql')).sort())db.exec(fs.readFileSync('drizzle/'+file,'utf8'));
// Development-only authenticated session for the synthetic preview account.
const previewSession=Array.from(crypto.getRandomValues(new Uint8Array(32)),b=>b.toString(16).padStart(2,'0')).join('');
const previewHash=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(previewSession))),b=>b.toString(16).padStart(2,'0')).join('');
db.prepare('INSERT INTO club_passwords VALUES(?,?,?,0,0,?)').run('preview','development-only','not-a-password-hash',Date.now());
db.prepare('INSERT INTO club_sessions VALUES(?,?,?)').run(previewHash,'preview',Date.now()+28800000);
const now=new Date().toISOString();db.prepare('INSERT INTO club_profiles VALUES(?,?,?,?,?,?)').run('preview','Cliente de demonstração','preview@example.test',null,now,now);
// Synthetic ranking records for visual QA only; never production seed data.
for(const [id,name,points] of [['qa-ana','Ana Santos',42],['qa-bruno','Bruno Oliveira',31],['qa-carla','Carla Souza',24]]){db.prepare('INSERT INTO club_profiles VALUES(?,?,?,?,?,?)').run(id,name,id+'@example.test',null,now,now);for(let n=0;n<points;n++)db.prepare('INSERT INTO club_keys(code,batch_id,label,created_at,used_by,used_email,used_at) VALUES(?,?,?,?,?,?,?)').run(id+n,'qa','Preview',now,id,id+'@example.test',now)}
const qaPhoto='data:image/png;base64,'+fs.readFileSync('web/assets/original-ff-garena-com.png').toString('base64');db.prepare('INSERT INTO club_profile_photos VALUES(?,?,?)').run('qa-ana',qaPhoto,now);db.prepare('INSERT INTO club_profile_photos VALUES(?,?,?)').run('preview',qaPhoto,now);
class Statement{constructor(sql,args=[]){this.sql=sql;this.args=args}bind(...args){return new Statement(this.sql,args)}execute(){const q=db.prepare(this.sql);if(q.columns().length)return {results:q.all(...this.args),meta:{changes:Number(db.prepare('SELECT changes() n').get().n)}};const r=q.run(...this.args);return {results:[],meta:{changes:Number(r.changes)}}}async all(){return this.execute()}async run(){return this.execute()}}
const env={ADMIN_EMAIL:'preview@example.test',DEMO_POINTS:'10000',DB:{prepare:s=>new Statement(s),async batch(items){db.exec('BEGIN');try{const r=items.map(s=>s.execute());db.exec('COMMIT');return r}catch(e){db.exec('ROLLBACK');throw e}}}};
const portIndex=process.argv.indexOf('--port'),hostIndex=process.argv.indexOf('--host');
const previewPort=Number(portIndex>=0?process.argv[portIndex+1]:process.env.PORT||3000),previewHost=hostIndex>=0?process.argv[hostIndex+1]:'0.0.0.0';
const server=http.createServer(async(req,res)=>{try{if(req.url.startsWith('/__mobile')){const width=Math.max(320,Math.min(900,Number(new URL(req.url,'http://localhost').searchParams.get('width'))||390));res.writeHead(200,{'Content-Type':'text/html'});res.end('<html><body style="margin:0;background:#ddd"><iframe title="Mobile preview" src="/" style="width:'+width+'px;height:900px;border:0"></iframe></body></html>');return}let chunks=[];for await(const c of req)chunks.push(c);const headers=new Headers(req.headers);headers.set('cookie','__Host-dg_session='+previewSession);headers.set('oai-authenticated-user-id','preview');headers.set('oai-authenticated-user-email','preview@example.test');const scheme=req.headers['x-forwarded-proto']||'http';const request=new Request(scheme+'://'+req.headers.host+req.url,{method:req.method,headers,body:['GET','HEAD'].includes(req.method)?undefined:Buffer.concat(chunks)});const response=await worker.fetch(request,env);res.writeHead(response.status,Object.fromEntries(response.headers));res.end(Buffer.from(await response.arrayBuffer()))}catch(e){res.writeHead(500);res.end('Preview error')}});
server.listen(previewPort,previewHost,()=>console.log('Development preview listening on '+previewPort));
