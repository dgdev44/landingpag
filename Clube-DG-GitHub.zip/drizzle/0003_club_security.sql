CREATE TABLE club_passwords (user_id TEXT PRIMARY KEY NOT NULL, salt TEXT NOT NULL, password_hash TEXT NOT NULL, failed_attempts INTEGER NOT NULL DEFAULT 0, locked_until INTEGER NOT NULL DEFAULT 0, updated_at INTEGER NOT NULL);
--> statement-breakpoint
CREATE TABLE club_sessions (token_hash TEXT PRIMARY KEY NOT NULL, user_id TEXT NOT NULL, expires_at INTEGER NOT NULL);
--> statement-breakpoint
CREATE INDEX club_sessions_user ON club_sessions(user_id);
